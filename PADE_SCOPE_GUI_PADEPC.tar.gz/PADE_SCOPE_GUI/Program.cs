﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Threading;

//Note -- Consider building a small status menu containing connection status and PADE Control Server Status

namespace PP_GUI
{
    public class Event
    {
        public int EvNum;
        public int FrameNum;
        public int HitCount;
        public int TimeStamp;
        public int FirstTime;
        public int BoardId;
        public int[,] Channels;
        public long[] Ticks;
        public byte[,] RawBytes;
        public Event()
        {
            Channels = new int[32, 128];
            Ticks = new long[32];
            RawBytes = new byte[32, 266];
            for (int i = 0; i < 32; i++)
            { RawBytes[i, 0] = 99; }
        }
    }

    public class Run
    {
        public int num;
        public string InFileName = "";
        public string OutFileName = "";
        public FileStream file;
        public StreamReader sr;
        public StreamWriter sw;
        public int start_evt_num;
        public int stop_evt_num;
        public string[] spill_status;
        public LinkedList<Event> Events;
        public Run()
        {
            num = 0;
            start_evt_num = 0;
            stop_evt_num = 0;
            if (Events != null) { Events.Clear(); }
            else { Events = new LinkedList<Event>(); }
        }
    }

    static class PP
    {
        public static frmGUI myGUI;
        public static Run myRun;

        public static List<Plot0> PlotList = new List<Plot0>();
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            myGUI = new frmGUI();
            myRun = new Run();



            Application.Run(myGUI);
        }

        public static void OpenNetworkSettings()
        {
            System.Console.WriteLine("Opening Network Settings Form");
            NetSettings n = new NetSettings();
            n.Show();


        }

        public static void OpenPlot()
        {
            Plot0 p = new Plot0();
            PlotList.Add(p);
            p.Show();
        }

        public static void ClosePlot(Plot0 p)
        {
            if (PlotList.Contains(p))
            {
                PlotList.Remove(p);
                p.Close();
            }
        }

        public static void ReadSpill()
        {
            myRun.Events.Clear();

            Event e = new Event();
            myRun.Events.AddLast(e);

            //try

        }
        public static void ReadRun()
        {
            //string fname = "";
            //myRun.Events.Clear();
            //myRun.start_evt_num = Convert.ToInt32(myGUI.udStart.Value);
            //myRun.stop_evt_num = Convert.ToInt32(myGUI.ud_Stop.Value);
            //Event e = new Event();
            ////try
            //{
            //    if (myGUI.txtInFile.Text.Length > 0)
            //    { fname = myGUI.txtInFile.Text; }
            //    // Specify file, instructions, and privelegdes
            //    myRun.file = new FileStream(fname, FileMode.Open, FileAccess.Read);
            //    // Create a new stream to read from a file
            //    if (myGUI.txtOutFile.Text == "") { myGUI.txtOutFile.Text = myGUI.txtInFile.Text + "out"; }
            //    myRun.sr = new StreamReader(myRun.file);
            //    myRun.sw = new StreamWriter(myGUI.txtOutFile.Text);


            //    while (myRun.sr.EndOfStream == false)
            //    {
            //        bool less_than_start = true;
            //        bool more_than_stop = false;
            //        string s = myRun.sr.ReadLine();
            //        s = s.ToLower();
            //        //ParseInputLine(s, out e);

            //        if (myRun.Events.Count >= myRun.start_evt_num) { less_than_start = false; }
            //        else { less_than_start = true; }
            //        if ((myRun.Events.Count < myRun.stop_evt_num) | (myRun.stop_evt_num == 0)) { more_than_stop = false; }
            //        else { more_than_stop = true; }
            //        if (!more_than_stop)
            //        {
            //            if (e.EvNum > 0)
            //            {
            //                if (!less_than_start)
            //                {
            //                    if (e.EvNum < 100)
            //                    { myRun.Events.AddLast(e); }
            //                }
            //                Outputevent_ROOT(e);
            //                myGUI.lblNumEvts.Text = e.EvNum.ToString();
            //                e = null;
            //                e = new Event();
            //                Application.DoEvents();

            //            }
            //        }
            //        else
            //        {
            //            myRun.sr.Close();
            //            myRun.sw.Close();
            //            myRun.file.Close();
            //            break;
            //        }

            //    }
            //}
            ////catch { return; };

        }

        public static void ParseInput(byte[] pack, ref Event evt, ref bool complete)
        {
            if (pack[0] == 1) //data
            {
                complete = false;
                evt.FrameNum = pack[4] * 256 + pack[5];
                int ch = pack[6];
                evt.HitCount = pack[9] * 256 + pack[8];

                for (int i = 0; i < 60; i++)
                {
                    evt.Channels[ch, 2 * i + 1] = pack[15 + 4 * i] * 256 + pack[14 + 4 * i];
                    evt.Channels[ch, 2 * i ]    = pack[17 + 4 * i] * 256 + pack[16 + 4 * i];
                }
                if (ch == 31) { complete = true; }
            }
            else
            {
                complete = true;
            }

            //for (int k = 0; k < c - 4; k++)
            //{
            //    lw[k] = t.Substring(36 + 8 * k, 8);
            //    //now swap them around
            //    string t1 = lw[k].Substring(0, 2);
            //    string t2 = lw[k].Substring(2, 2);
            //    string t3 = lw[k].Substring(4, 2);
            //    string t4 = lw[k].Substring(6, 2);
            //    lw[k] = t4 + t3 + t2 + t1;
            //    //s += lw[k] + " ";
            //}
        }

        /// <summary>
        /// EvNum TimeStamp FrameNum HitCount MaxAmp[ch]
        /// </summary>
        /// <param name="e"></param>
        //public static void Outputevent_ROOT(Event e)
        //{
        //    float fts = (float)e.TimeStamp / 75;
        //    float sum1;

        //    //string t = e.EvNum + " " + e.TimeStamp.ToString() + " " + e.FrameNum.ToString()+" "+ e.HitCount.ToString();
        //    string t = e.EvNum + " " + fts.ToString("F3") + " " + e.FrameNum.ToString() + " " + e.HitCount.ToString();
        //    for (int ch = 0; ch < 16; ch++)
        //    {
        //        int max = 0; sum1 = 0;
        //        for (int sample = 1; sample < 8; sample++)
        //        {
        //            //if (e.Channels[ch, sample] > max) { max = e.Channels[ch, sample]; }
        //            if (e.Channels[ch, sample] > 100) { sum1 += (e.Channels[ch, sample] - 100); }
        //        }
        //        //Nov9: oops I think there is a mess in the data. I will use only 2 and 3 for now
        //        //max = e.Channels[ch, 2] + e.Channels[ch, 3];
        //        t += " " + sum1.ToString();
        //    }
        //    myRun.sw.WriteLine(t);

        //    t = e.EvNum + " " + fts.ToString("F3") + " " + e.FrameNum.ToString() + " " + (e.HitCount + 1).ToString();
        //    for (int ch = 0; ch < 16; ch++)
        //    {
        //        int max = 0; sum1 = 0;
        //        for (int sample = 9; sample < 15; sample++)
        //        {
        //            //if (e.Channels[ch, sample] > max) { max = e.Channels[ch, sample]; }
        //            if (e.Channels[ch, sample] > 100) { sum1 += (e.Channels[ch, sample] - 100); }
        //        }
        //        //Nov9: oops I think there is a mess in the data. I will use only 2 and 3 for now
        //        //max = e.Channels[ch, 2] + e.Channels[ch, 3];
        //        t += " " + sum1.ToString();
        //    }
        //    myRun.sw.WriteLine(t);
        //}
    }
}
