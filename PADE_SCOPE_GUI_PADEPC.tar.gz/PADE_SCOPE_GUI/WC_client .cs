﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using NetMQ; 

namespace PP_GUI
{
    public static class WC_client
    {
        public static bool ClientOpen = false;
		//public static string controller_name = "FTBFWC01.FNAL.GOV";
		public static string controller_name = "localhost";
        public static int controller_port = 5001;
        public static Socket StensSocket;
        static string lastSpillState = "0";
	    public static string lastEndSpillTime ="0";
		public static NetMQContext ctx = NetMQContext.Create();

        static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length];
            for (int i = 0; i < str.Length; i++)
            {
                bytes[i] = (byte)(str[i]);
            }
            return bytes;
        }

        static string GetString(byte[] bytes, int len)
        {
            char[] chars = new char[len];
            for (int i = 0; i < len; i++)
            {
                chars[i] = (char)bytes[i];
            }
            return new string(chars);
        }

		public static void NetMQOpen() {

			var client = ctx.CreateRequestSocket();
			client.Connect ("tcp://127.0.0.1:5555");
			client.Send ("Hello");
			string fromClient = client.ReceiveString ();
			Console.WriteLine ("From Server: {0}", fromClient);
			client.Disconnect ("tcp://127.0.0.1:5555");



		}

        public static void Open()
        {
            ClientOpen = false;
		
            try
            {
                StensSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                StensSocket.Blocking = true;
                StensSocket.ReceiveBufferSize = 1024000;
                StensSocket.Connect(controller_name, 5001);
                Thread.Sleep(100);
                ClientOpen = true;
            }
            catch { throw new NotImplementedException("failed to connect to FTBFWC01"); }
        }

        public static void EnableTrig()
        {
            //try
            //{
                byte[] buf = GetBytes("wr 88 2\r\n");
                StensSocket.Send(buf);
                byte[] rec_buf = new byte[1000];
                Thread.Sleep(100);
                Exception e = new Exception("you should not be messing with WC trigger!");
            //}
            //catch { }
        }

        public static void check_status(out bool in_spill, out string num_trig, out string time)
        {
            try
            {
                byte[] buf = GetBytes("rd 5\r\n");
                StensSocket.Send(buf);
                byte[] rec_buf = new byte[100];
                Thread.Sleep(10);
                int ret_len = StensSocket.Receive(rec_buf);
                string s = GetString(rec_buf, ret_len);
                num_trig = s.Substring(0, 4);
            }
            catch
            { num_trig = "xxx"; }
            try
            {
                byte[] buf = GetBytes("time\r\n");
                StensSocket.Send(buf);
                byte[] rec_buf = new byte[100];
                Thread.Sleep(10);
                int ret_len = StensSocket.Receive(rec_buf);
                string s = GetString(rec_buf, ret_len);
                time=s.Substring(0,s.IndexOf("\r"));
            }
            catch
            { time = " time unknown"; }

            try
            {
                byte[] buf = GetBytes("rd b\r\n");
                StensSocket.Send(buf);
                byte[] rec_buf = new byte[1000];
                Thread.Sleep(10);
                int ret_len = StensSocket.Receive(rec_buf);
                string s = GetString(rec_buf, ret_len);
                string sss = s.Substring(3, 1);
                if (sss != lastSpillState)
                {
                    Console.WriteLine();
		            if (lastSpillState=="8") { lastEndSpillTime = time; } // just transitioned out of spill
                    lastSpillState = sss;
                    Console.Write("SpillState= ");
                }
                Console.Write(sss);
                if (sss == "8") { in_spill = true; } else { in_spill = false; }
            }
            catch
            { in_spill = false; }

        }

        public static byte[] read_TDC(out int len)
        {
            //byte[] b = new byte[5];
            //byte[] buf = GetBytes("rdb\r\n");
            //StensSocket.Send(buf);
            //byte[] rec_buf = new byte[512000];
            //Thread.Sleep(500);
            //int ret_len = StensSocket.Receive(rec_buf);
            //len = ret_len;
            //return rec_buf;
            len = 0;
            byte[] fake = new byte[1];
            return fake;
        }


        public static void Close()
        {
            StensSocket.Close();
            ClientOpen = false;
        }
    }

}
