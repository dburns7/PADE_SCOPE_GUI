﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.IO;


namespace PP_GUI
{
    public static class RC_client
    {
        public static bool ClientOpen = false;
        
        private static string rcsAddress = "192.168.0.225";
        private static int rcsPort = 23;

     


        private static TcpClient client;
        private static NetworkStream stream;
        private static StreamReader SR;
        private static StreamWriter SW;
        private static int max_timeout;
        private static int timeout;

        public static void Open()
        {
            ClientOpen = false;
            try
            {
                Console.WriteLine("Running on host: " + System.Environment.MachineName);
				if (System.Environment.MachineName.Contains("ShashDAQ"))// || System.Environment.MachineName.Contains("localhost"))
                {                  
                    Console.WriteLine("Connecting to remote PADE Scope");
					client = new TcpClient("192.168.0.225", 23);
                }
                else
                {
                    Console.WriteLine("Connecting to local PADE Scope");
                    client = new TcpClient("127.0.0.1", 23);
                }
                stream = client.GetStream();
                SW = new StreamWriter(stream);
                SR = new StreamReader(stream);
                SW.AutoFlush = true;
                max_timeout = 100;
                ClientOpen = true;
            }
            catch { }
        }

        public static string getRCSAddress()
        {
            return rcsAddress;
        }

        public static int getRCSPort()
        {
            return rcsPort;
        }

        public static bool updateRCSServer(string address, int port)
        {
            System.Console.WriteLine("Changing RCS Address from {0} to {1} and port from {2} to {3}", rcsAddress, address, rcsPort, port);
            rcsAddress = address;
            rcsPort = port;

            if (ClientOpen)
            {

                Close();
            }

            //This should get migrated to Open, and open should get updated with some more checking/error handling code
            try
            {
                Console.WriteLine("Connecting to remote PADE Scope");
                client = new TcpClient(rcsAddress, rcsPort);
                stream = client.GetStream();
                SW = new StreamWriter(stream);
                SR = new StreamReader(stream);
                SW.AutoFlush = true;
                max_timeout = 100;
                ClientOpen = true;
            }
            catch
            {
                return false;

            }
            return true;


        }

        public static bool Arm()
        {
            SW.WriteLine("arm");
            timeout = 0;
            while ((SR.ReadLine() != "arm") && (timeout < max_timeout)) { System.Threading.Thread.Sleep(1); timeout++; }
            if (timeout < max_timeout) { return true; } else { return false; }
        }

        public static bool Disarm()
        {
            SW.WriteLine("disarm");
            timeout = 0;
            while ((SR.ReadLine() != "disarm") && (timeout < max_timeout)) { System.Threading.Thread.Sleep(1); timeout++; }
            if (timeout < max_timeout) { return true; } else { return false; }
        }

        public static bool SoftwareTrig()
        {
            SW.WriteLine("trig");
            timeout = 0;
            while ((SR.ReadLine() != "trig") && (timeout < max_timeout)) { System.Threading.Thread.Sleep(1); timeout++; }
            if (timeout < max_timeout) { return true; } else { return false; }
        }

        public static bool ReadN(int n)
        {
            SW.WriteLine("read " + n.ToString());
            timeout = 0;
            while ((SR.ReadLine().Contains("read") == false) && (timeout < max_timeout)) { System.Threading.Thread.Sleep(1); timeout++; }
            if (timeout < max_timeout) { return true; } else { return false; }

        }

        public static bool ReadAll()
        {
            SW.WriteLine("read all");
            timeout = 0;
            Console.WriteLine();
            Console.Write("ReadAll sent "); 
            while ((SR.ReadLine().Contains("read") == false) && (timeout < max_timeout)) { 
                System.Threading.Thread.Sleep(1); 
                timeout++; 
            }
            if (timeout < max_timeout) { return true; } else { return false; }
        }

        public static bool Clear()
        {
            SW.WriteLine("clear");
            timeout = 0;
            while ((SR.ReadLine() != "clear") && (timeout < max_timeout)) { System.Threading.Thread.Sleep(1); timeout++; }
            if (timeout < max_timeout) { return true; } else { return false; }
        }

        public static bool SetMaxTrig(int val)
        {
            SW.WriteLine("maxtrig " + val.ToString());
            timeout = 0;
            return true;
        }

        public static int GetStatus(out string[] status)
        {
            string[] n = new string[10];
            n[0] = "";
            n[1] = "";
            n[2] = "";
            n[3] = "st=";
            n[4] = "ARM=";
            n[5] = "t in mem=";
            n[6] = "err reg=";
            n[7] = "last trig=";
            n[8] = "Ptemp=";
            n[9] = "Stemp=";
            int lines = 0;
            int num_pade = 0;
            string[] tok = new string[1];

            SW.WriteLine("status");

            string t = SR.ReadLine();
            lines++;
            if (t.ToUpper().Contains("MASTER") || t.ToUpper().Contains("SLAVE"))
            {
                string[] delim = new string[1];
                delim[0] = " ";
                tok = t.Split(delim, StringSplitOptions.RemoveEmptyEntries);
                num_pade = Convert.ToInt32(tok[0]);
            }


            lines = num_pade;
            string[] s = new string[lines+1];
            if ((tok.Length < 9 * num_pade) || (num_pade == 0))
            {
                for (int i = 0; i < s.Length; i++)
                {
                    s[i] = "error";
                }
                if (num_pade == 0) { s = new string[1]; s[0] = "error, 0 PADE"; }
            }
            else
            {
                int j = 0;
                int k = 0;
                s[k] = "";
                for (int i = 0; i < tok.Length; i++)
                {
                    
                    if (j>0)
                    {
                        s[k] += n[j-9*k]+tok[j] + " ";
                    }
                    j++;
                    if ((j-1) >= (9 * (k + 1))) { k++; s[k] = ""; }
                }
            }
            status = s;
            return lines;
        }



        public static void Close()
        {
            stream.Close();
            client.Close();
            ClientOpen = false;
        }

    }

}
