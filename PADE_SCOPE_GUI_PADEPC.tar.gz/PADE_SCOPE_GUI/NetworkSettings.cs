﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PP_GUI
{
    public partial class NetSettings : Form
    {
        public NetSettings()
        {
            InitializeComponent();
            if (RC_client.ClientOpen)
            {
                btn_rcsConnect.BackColor = Color.Green;
            }
            else
            {
                btn_rcsConnect.BackColor = Color.Firebrick;
            }
            rcsServer.Text = RC_client.getRCSAddress();
            rcsPort.Text = Convert.ToString(RC_client.getRCSPort());
            wcsServer.Text = WC_client.controller_name;
            wcsPort.Text = Convert.ToString(WC_client.controller_port);

        }

        private void NetSettings_Load(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string address = rcsServer.Text;
            int port = Convert.ToInt32(rcsPort.Text);
            RC_client.updateRCSServer(address, port);
        }

        private void btn_rcsConnect_Click(Object sender, EventArgs e)
        {

            string address = rcsServer.Text;
            int port = Convert.ToInt32(rcsPort.Text);
            RC_client.updateRCSServer(address, port);
            if (RC_client.ClientOpen)
            {
                btn_rcsConnect.BackColor = Color.Green;
            }
            else
            {
                btn_rcsConnect.BackColor = Color.Firebrick;
            }
            
               
        }
        private void btn_wcsConnect_Click(Object sender, EventArgs e)
        {
            System.Console.WriteLine("WCS Connect Skeleton Button");

        }

        private void btn_NetMQ_Click(Object sender, EventArgs e)
        {
            WC_client.NetMQOpen();

        }
    }
}
