﻿namespace PP_GUI
{
    partial class NetSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rcsServer = new System.Windows.Forms.TextBox();
            this.wcsServer = new System.Windows.Forms.TextBox();
            this.wcsPort = new System.Windows.Forms.TextBox();
            this.rcsPort = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btn_rcsConnect = new System.Windows.Forms.Button();
            this.btn_wcsConnect = new System.Windows.Forms.Button();
            this.btn_NetMQ = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rcsServer
            // 
            this.rcsServer.Location = new System.Drawing.Point(12, 12);
            this.rcsServer.Name = "rcsServer";
            this.rcsServer.Size = new System.Drawing.Size(100, 20);
            this.rcsServer.TabIndex = 0;
            // 
            // wcsServer
            // 
            this.wcsServer.Location = new System.Drawing.Point(12, 50);
            this.wcsServer.Name = "wcsServer";
            this.wcsServer.Size = new System.Drawing.Size(100, 20);
            this.wcsServer.TabIndex = 1;
            // 
            // wcsPort
            // 
            this.wcsPort.Location = new System.Drawing.Point(118, 50);
            this.wcsPort.Name = "wcsPort";
            this.wcsPort.Size = new System.Drawing.Size(38, 20);
            this.wcsPort.TabIndex = 2;
            // 
            // rcsPort
            // 
            this.rcsPort.Location = new System.Drawing.Point(118, 12);
            this.rcsPort.Name = "rcsPort";
            this.rcsPort.Size = new System.Drawing.Size(38, 20);
            this.rcsPort.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(175, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Remote Control Server";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "WireChamber Server";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(197, 226);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 6;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(116, 226);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btn_rcsConnect
            // 
            this.btn_rcsConnect.BackColor = System.Drawing.Color.Firebrick;
            this.btn_rcsConnect.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_rcsConnect.Location = new System.Drawing.Point(308, 10);
            this.btn_rcsConnect.Name = "btn_rcsConnect";
            this.btn_rcsConnect.Size = new System.Drawing.Size(27, 23);
            this.btn_rcsConnect.TabIndex = 8;
            this.btn_rcsConnect.UseVisualStyleBackColor = false;
            this.btn_rcsConnect.Click += new System.EventHandler(this.btn_rcsConnect_Click);
            // 
            // btn_wcsConnect
            // 
            this.btn_wcsConnect.BackColor = System.Drawing.Color.Firebrick;
            this.btn_wcsConnect.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_wcsConnect.Location = new System.Drawing.Point(308, 48);
            this.btn_wcsConnect.Name = "btn_wcsConnect";
            this.btn_wcsConnect.Size = new System.Drawing.Size(27, 23);
            this.btn_wcsConnect.TabIndex = 9;
            this.btn_wcsConnect.UseVisualStyleBackColor = false;
            this.btn_wcsConnect.Click += new System.EventHandler(this.btn_wcsConnect_Click);
            // 
            // btn_NetMQ
            // 
            this.btn_NetMQ.Location = new System.Drawing.Point(12, 114);
            this.btn_NetMQ.Name = "btn_NetMQ";
            this.btn_NetMQ.Size = new System.Drawing.Size(75, 23);
            this.btn_NetMQ.TabIndex = 10;
            this.btn_NetMQ.Text = "testNetMQ";
            this.btn_NetMQ.UseVisualStyleBackColor = true;
            this.btn_NetMQ.Click += new System.EventHandler(this.btn_NetMQ_Click);

            // 
            // NetSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 261);
            this.Controls.Add(this.btn_NetMQ);
            this.Controls.Add(this.btn_wcsConnect);
            this.Controls.Add(this.btn_rcsConnect);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rcsPort);
            this.Controls.Add(this.wcsPort);
            this.Controls.Add(this.wcsServer);
            this.Controls.Add(this.rcsServer);
            this.Name = "NetSettings";
            this.Text = "Network Settings";
            this.Load += new System.EventHandler(this.NetSettings_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox rcsServer;
        private System.Windows.Forms.TextBox wcsServer;
        private System.Windows.Forms.TextBox wcsPort;
        private System.Windows.Forms.TextBox rcsPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btn_rcsConnect;
        private System.Windows.Forms.Button btn_wcsConnect;
        private System.Windows.Forms.Button btn_NetMQ;
    }
}