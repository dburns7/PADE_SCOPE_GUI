namespace PP_GUI
{
  partial class Plot0
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.zg1 = new ZedGraph.ZedGraphControl();
        this.ud_MaxY = new System.Windows.Forms.NumericUpDown();
        this.ud_MinY = new System.Windows.Forms.NumericUpDown();
        this.label1 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.label3 = new System.Windows.Forms.Label();
        this.ud_MinX = new System.Windows.Forms.NumericUpDown();
        this.label4 = new System.Windows.Forms.Label();
        this.ud_MaxX = new System.Windows.Forms.NumericUpDown();
        this.chk_persist = new System.Windows.Forms.CheckBox();
        this.panel1 = new System.Windows.Forms.Panel();
        this.btnAutoScale = new System.Windows.Forms.Button();
        this.btnClose = new System.Windows.Forms.Button();
        this.btnPrevE = new System.Windows.Forms.Button();
        this.btnNextE = new System.Windows.Forms.Button();
        this.txtEvt = new System.Windows.Forms.TextBox();
        this.colorDialog1 = new System.Windows.Forms.ColorDialog();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.label7 = new System.Windows.Forms.Label();
        this.label6 = new System.Windows.Forms.Label();
        this.label5 = new System.Windows.Forms.Label();
        this.lblBooardID = new System.Windows.Forms.Label();
        ((System.ComponentModel.ISupportInitialize)(this.ud_MaxY)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.ud_MinY)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.ud_MinX)).BeginInit();
        ((System.ComponentModel.ISupportInitialize)(this.ud_MaxX)).BeginInit();
        this.panel1.SuspendLayout();
        this.groupBox1.SuspendLayout();
        this.SuspendLayout();
        // 
        // zg1
        // 
        this.zg1.Location = new System.Drawing.Point(4, 1);
        this.zg1.Margin = new System.Windows.Forms.Padding(4);
        this.zg1.Name = "zg1";
        this.zg1.ScrollGrace = 0D;
        this.zg1.ScrollMaxX = 0D;
        this.zg1.ScrollMaxY = 0D;
        this.zg1.ScrollMaxY2 = 0D;
        this.zg1.ScrollMinX = 0D;
        this.zg1.ScrollMinY = 0D;
        this.zg1.ScrollMinY2 = 0D;
        this.zg1.Size = new System.Drawing.Size(654, 411);
        this.zg1.TabIndex = 0;
        // 
        // ud_MaxY
        // 
        this.ud_MaxY.Location = new System.Drawing.Point(82, 20);
        this.ud_MaxY.Maximum = new decimal(new int[] {
            16500,
            0,
            0,
            0});
        this.ud_MaxY.Name = "ud_MaxY";
        this.ud_MaxY.Size = new System.Drawing.Size(71, 20);
        this.ud_MaxY.TabIndex = 5;
        this.ud_MaxY.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
        // 
        // ud_MinY
        // 
        this.ud_MinY.Location = new System.Drawing.Point(82, 75);
        this.ud_MinY.Maximum = new decimal(new int[] {
            16000,
            0,
            0,
            0});
        this.ud_MinY.Name = "ud_MinY";
        this.ud_MinY.Size = new System.Drawing.Size(71, 20);
        this.ud_MinY.TabIndex = 6;
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Location = new System.Drawing.Point(91, 4);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(37, 13);
        this.label1.TabIndex = 7;
        this.label1.Text = "Max Y";
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Location = new System.Drawing.Point(94, 98);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(34, 13);
        this.label2.TabIndex = 8;
        this.label2.Text = "Min Y";
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Location = new System.Drawing.Point(3, 34);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(34, 13);
        this.label3.TabIndex = 10;
        this.label3.Text = "Min X";
        // 
        // ud_MinX
        // 
        this.ud_MinX.Location = new System.Drawing.Point(5, 49);
        this.ud_MinX.Maximum = new decimal(new int[] {
            4095,
            0,
            0,
            0});
        this.ud_MinX.Name = "ud_MinX";
        this.ud_MinX.Size = new System.Drawing.Size(71, 20);
        this.ud_MinX.TabIndex = 9;
        // 
        // label4
        // 
        this.label4.AutoSize = true;
        this.label4.Location = new System.Drawing.Point(187, 33);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(37, 13);
        this.label4.TabIndex = 13;
        this.label4.Text = "Max X";
        // 
        // ud_MaxX
        // 
        this.ud_MaxX.Location = new System.Drawing.Point(158, 49);
        this.ud_MaxX.Maximum = new decimal(new int[] {
            4095,
            0,
            0,
            0});
        this.ud_MaxX.Name = "ud_MaxX";
        this.ud_MaxX.Size = new System.Drawing.Size(71, 20);
        this.ud_MaxX.TabIndex = 12;
        this.ud_MaxX.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
        this.ud_MaxX.ValueChanged += new System.EventHandler(this.ud_MaxX_ValueChanged);
        // 
        // chk_persist
        // 
        this.chk_persist.AutoSize = true;
        this.chk_persist.Location = new System.Drawing.Point(172, 3);
        this.chk_persist.Name = "chk_persist";
        this.chk_persist.Size = new System.Drawing.Size(57, 17);
        this.chk_persist.TabIndex = 15;
        this.chk_persist.Text = "Persist";
        this.chk_persist.UseVisualStyleBackColor = true;
        // 
        // panel1
        // 
        this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        this.panel1.Controls.Add(this.btnAutoScale);
        this.panel1.Controls.Add(this.chk_persist);
        this.panel1.Controls.Add(this.label4);
        this.panel1.Controls.Add(this.ud_MaxX);
        this.panel1.Controls.Add(this.label3);
        this.panel1.Controls.Add(this.ud_MinX);
        this.panel1.Controls.Add(this.label2);
        this.panel1.Controls.Add(this.label1);
        this.panel1.Controls.Add(this.ud_MinY);
        this.panel1.Controls.Add(this.ud_MaxY);
        this.panel1.Location = new System.Drawing.Point(423, 419);
        this.panel1.Name = "panel1";
        this.panel1.Size = new System.Drawing.Size(236, 119);
        this.panel1.TabIndex = 47;
        // 
        // btnAutoScale
        // 
        this.btnAutoScale.Location = new System.Drawing.Point(82, 46);
        this.btnAutoScale.Name = "btnAutoScale";
        this.btnAutoScale.Size = new System.Drawing.Size(71, 23);
        this.btnAutoScale.TabIndex = 14;
        this.btnAutoScale.Text = "auto scale";
        this.btnAutoScale.UseVisualStyleBackColor = true;
        this.btnAutoScale.Click += new System.EventHandler(this.btnAutoScale_Click);
        // 
        // btnClose
        // 
        this.btnClose.Location = new System.Drawing.Point(606, 562);
        this.btnClose.Name = "btnClose";
        this.btnClose.Size = new System.Drawing.Size(53, 41);
        this.btnClose.TabIndex = 48;
        this.btnClose.Text = "CLOSE";
        this.btnClose.UseVisualStyleBackColor = true;
        this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
        // 
        // btnPrevE
        // 
        this.btnPrevE.Location = new System.Drawing.Point(423, 562);
        this.btnPrevE.Name = "btnPrevE";
        this.btnPrevE.Size = new System.Drawing.Size(50, 41);
        this.btnPrevE.TabIndex = 49;
        this.btnPrevE.Text = "<<";
        this.btnPrevE.UseVisualStyleBackColor = true;
        this.btnPrevE.Click += new System.EventHandler(this.btnPrevE_Click);
        // 
        // btnNextE
        // 
        this.btnNextE.Location = new System.Drawing.Point(531, 562);
        this.btnNextE.Name = "btnNextE";
        this.btnNextE.Size = new System.Drawing.Size(50, 41);
        this.btnNextE.TabIndex = 50;
        this.btnNextE.Text = ">>";
        this.btnNextE.UseVisualStyleBackColor = true;
        this.btnNextE.Click += new System.EventHandler(this.btnNextE_Click);
        // 
        // txtEvt
        // 
        this.txtEvt.Location = new System.Drawing.Point(478, 573);
        this.txtEvt.Name = "txtEvt";
        this.txtEvt.Size = new System.Drawing.Size(47, 20);
        this.txtEvt.TabIndex = 51;
        this.txtEvt.Text = "1";
        this.txtEvt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.label7);
        this.groupBox1.Controls.Add(this.label6);
        this.groupBox1.Controls.Add(this.label5);
        this.groupBox1.Location = new System.Drawing.Point(233, 420);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(180, 197);
        this.groupBox1.TabIndex = 52;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "receiver";
        // 
        // label7
        // 
        this.label7.AutoSize = true;
        this.label7.Location = new System.Drawing.Point(5, 45);
        this.label7.Name = "label7";
        this.label7.Size = new System.Drawing.Size(35, 13);
        this.label7.TabIndex = 2;
        this.label7.Text = "label7";
        this.label7.Visible = false;
        // 
        // label6
        // 
        this.label6.AutoSize = true;
        this.label6.Location = new System.Drawing.Point(5, 30);
        this.label6.Name = "label6";
        this.label6.Size = new System.Drawing.Size(35, 13);
        this.label6.TabIndex = 1;
        this.label6.Text = "label6";
        this.label6.Visible = false;
        // 
        // label5
        // 
        this.label5.AutoSize = true;
        this.label5.Location = new System.Drawing.Point(5, 15);
        this.label5.Name = "label5";
        this.label5.Size = new System.Drawing.Size(35, 13);
        this.label5.TabIndex = 0;
        this.label5.Text = "label5";
        this.label5.Visible = false;
        // 
        // lblBooardID
        // 
        this.lblBooardID.AutoSize = true;
        this.lblBooardID.Location = new System.Drawing.Point(420, 546);
        this.lblBooardID.Name = "lblBooardID";
        this.lblBooardID.Size = new System.Drawing.Size(35, 13);
        this.lblBooardID.TabIndex = 53;
        this.lblBooardID.Text = "label8";
        this.lblBooardID.Visible = false;
        // 
        // Plot0
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(671, 623);
        this.ControlBox = false;
        this.Controls.Add(this.lblBooardID);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.txtEvt);
        this.Controls.Add(this.btnNextE);
        this.Controls.Add(this.btnPrevE);
        this.Controls.Add(this.btnClose);
        this.Controls.Add(this.panel1);
        this.Controls.Add(this.zg1);
        this.Name = "Plot0";
        this.Text = "Plot0";
        ((System.ComponentModel.ISupportInitialize)(this.ud_MaxY)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.ud_MinY)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.ud_MinX)).EndInit();
        ((System.ComponentModel.ISupportInitialize)(this.ud_MaxX)).EndInit();
        this.panel1.ResumeLayout(false);
        this.panel1.PerformLayout();
        this.groupBox1.ResumeLayout(false);
        this.groupBox1.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

      private ZedGraph.ZedGraphControl zg1;
      private System.Windows.Forms.NumericUpDown ud_MaxY;
      private System.Windows.Forms.NumericUpDown ud_MinY;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.NumericUpDown ud_MinX;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.NumericUpDown ud_MaxX;
      private System.Windows.Forms.CheckBox chk_persist;
      private System.Windows.Forms.Panel panel1;
      private System.Windows.Forms.Button btnAutoScale;
      public System.Windows.Forms.Button btnClose;
      public System.Windows.Forms.Button btnPrevE;
      public System.Windows.Forms.Button btnNextE;
      private System.Windows.Forms.TextBox txtEvt;
      private System.Windows.Forms.ColorDialog colorDialog1;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Label lblBooardID;
  }
}